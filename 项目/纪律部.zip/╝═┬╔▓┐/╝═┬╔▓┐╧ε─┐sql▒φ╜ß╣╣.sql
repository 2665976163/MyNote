/*
SQLyog Enterprise v12.09 (64 bit)
MySQL - 5.5.20 : Database - znsd_project
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`znsd_project` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `znsd_project`;

/*Table structure for table `t_account` */

DROP TABLE IF EXISTS `t_account`;

CREATE TABLE `t_account` (
  `accountId` int(11) NOT NULL AUTO_INCREMENT COMMENT '账号id',
  `account` varchar(255) NOT NULL COMMENT '账号名称',
  `psWord` varchar(255) NOT NULL COMMENT '密码',
  `headImg` varchar(255) DEFAULT NULL COMMENT '头像 做好用户不上传头像的准备',
  `status` varchar(255) NOT NULL COMMENT '状态，默认为未禁用',
  `classId` int(11) DEFAULT NULL COMMENT '班级id',
  PRIMARY KEY (`accountId`),
  UNIQUE KEY `account` (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8 COMMENT='账号表';

/*Data for the table `t_account` */

insert  into `t_account`(`accountId`,`account`,`psWord`,`headImg`,`status`,`classId`) values (1,'123','123123','file/headimg/yy.png','未禁用',1),(2,'222','222222','file/headimg/QQ1.jpg','未禁用',6),(135,'123123','123123','file/headimg/QQ图片20191021195039.jpg','未禁用',6),(136,'qqq','123123','file/headimg/ccc.png','未禁用',6);

/*Table structure for table `t_account_role` */

DROP TABLE IF EXISTS `t_account_role`;

CREATE TABLE `t_account_role` (
  `accountId` int(11) NOT NULL COMMENT '账号id',
  `roleId` int(11) NOT NULL COMMENT '角色id',
  UNIQUE KEY `accountId` (`accountId`,`roleId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='账号表&角色表';

/*Data for the table `t_account_role` */

insert  into `t_account_role`(`accountId`,`roleId`) values (1,1),(2,1),(135,1),(136,1);

/*Table structure for table `t_class` */

DROP TABLE IF EXISTS `t_class`;

CREATE TABLE `t_class` (
  `classId` int(11) NOT NULL AUTO_INCREMENT COMMENT '班级id',
  `className` varchar(255) DEFAULT NULL COMMENT '班级名称',
  `classCapacity` varchar(255) DEFAULT NULL COMMENT '班级容量',
  `classTeacher` varchar(255) DEFAULT NULL COMMENT '代班老师',
  PRIMARY KEY (`classId`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COMMENT='班级表';

/*Data for the table `t_class` */

insert  into `t_class`(`classId`,`className`,`classCapacity`,`classTeacher`) values (1,'18h3','30','周杰'),(4,'123','30','123'),(5,'123','123','123'),(6,'18h4','50','李天奇');

/*Table structure for table `t_class_dorm` */

DROP TABLE IF EXISTS `t_class_dorm`;

CREATE TABLE `t_class_dorm` (
  `classId` int(11) DEFAULT NULL COMMENT '班级id',
  `dormId` int(11) DEFAULT NULL COMMENT '宿舍id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='班级表&宿舍表';

/*Data for the table `t_class_dorm` */

/*Table structure for table `t_dorm` */

DROP TABLE IF EXISTS `t_dorm`;

CREATE TABLE `t_dorm` (
  `dormId` int(11) NOT NULL AUTO_INCREMENT COMMENT '宿舍id',
  `dormName` varchar(255) DEFAULT NULL COMMENT '宿舍名称 比如 3207 防止以后宿舍存储中文名称',
  `dormCapacity` varchar(255) DEFAULT NULL COMMENT '宿舍容量',
  `dormArea` varchar(255) DEFAULT NULL COMMENT '宿舍区域',
  PRIMARY KEY (`dormId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='宿舍表';

/*Data for the table `t_dorm` */

insert  into `t_dorm`(`dormId`,`dormName`,`dormCapacity`,`dormArea`) values (2,'3211','8','二栋宿舍楼'),(3,'1351','8','一栋宿舍楼'),(4,'a','10','c'),(8,'123','123','123');

/*Table structure for table `t_foul` */

DROP TABLE IF EXISTS `t_foul`;

CREATE TABLE `t_foul` (
  `foulId` int(11) NOT NULL AUTO_INCREMENT COMMENT '违纪id',
  `foulType` varchar(255) DEFAULT NULL COMMENT '违纪类型 比如：空调未关闭',
  PRIMARY KEY (`foulId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='违纪表';

/*Data for the table `t_foul` */

insert  into `t_foul`(`foulId`,`foulType`) values (1,'穿拖鞋'),(2,'未违纪');

/*Table structure for table `t_foul_foularea` */

DROP TABLE IF EXISTS `t_foul_foularea`;

CREATE TABLE `t_foul_foularea` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '编号id',
  `foulId` int(11) DEFAULT NULL COMMENT '违纪id',
  `areaId` int(11) DEFAULT NULL COMMENT '违纪区域id',
  `areaName` varchar(255) DEFAULT NULL COMMENT '违纪区域名称 比如：3207 || 18合一 等',
  `describe` varchar(255) DEFAULT NULL COMMENT '违纪描述',
  `foulTime` varchar(255) DEFAULT NULL COMMENT '违纪时间',
  `score` varchar(255) DEFAULT NULL COMMENT '评分',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COMMENT='违纪表&违纪区域';

/*Data for the table `t_foul_foularea` */

insert  into `t_foul_foularea`(`id`,`foulId`,`areaId`,`areaName`,`describe`,`foulTime`,`score`) values (1,2,2,'323','323被子','2019-02-13','7'),(2,2,1,'1901','1901','2019-02-30','6'),(3,1,1,'1901','1901','2019-02-14','5'),(4,1,2,'321','321','2019-02-16','5'),(5,1,2,'321','321','2019-02-16','5'),(6,1,2,'321','321','2019-02-16','5'),(7,1,2,'321','321鞋子','2019-02-16','5'),(8,1,2,'321','321','2019-02-16','3'),(9,1,2,'323','323鞋子','2019-11-14','5'),(10,2,2,'135',NULL,'2019-02-14','8'),(11,2,2,'135',NULL,'2019-02-15','8'),(12,2,1,'18合一',NULL,'2019-02-16','8'),(14,1,2,'323','鞋子','2019-02-15','6'),(15,1,2,'3211','鞋子','2019-02-15','6'),(16,1,2,'3208','鞋子','2019-02-15','7'),(17,1,2,'233','鞋子','2019-02-15','5'),(18,2,2,'136',NULL,'2019-02-15','8'),(19,1,1,'1901','1901','2019-02-14','5'),(20,2,1,'1901','','2019-02-14','4'),(21,1,1,'123222','123222','2019-11-18 08:11:16','123222');

/*Table structure for table `t_foularea` */

DROP TABLE IF EXISTS `t_foularea`;

CREATE TABLE `t_foularea` (
  `areaId` int(11) NOT NULL AUTO_INCREMENT COMMENT '违纪区域id',
  `areaType` varchar(255) DEFAULT NULL COMMENT '违纪区域类型 比如：班级||宿舍',
  PRIMARY KEY (`areaId`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='违纪区域表';

/*Data for the table `t_foularea` */

insert  into `t_foularea`(`areaId`,`areaType`) values (1,'教室'),(2,'宿舍');

/*Table structure for table `t_log` */

DROP TABLE IF EXISTS `t_log`;

CREATE TABLE `t_log` (
  `logId` int(11) NOT NULL AUTO_INCREMENT COMMENT '日志id',
  `account` varchar(255) DEFAULT NULL COMMENT '操作账号',
  `time` varchar(255) DEFAULT NULL COMMENT '操作时间',
  `target` varchar(255) DEFAULT NULL COMMENT '操作目标',
  `describe` varchar(255) DEFAULT NULL COMMENT '操作描述',
  PRIMARY KEY (`logId`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8 COMMENT='日志表';

/*Data for the table `t_log` */

insert  into `t_log`(`logId`,`account`,`time`,`target`,`describe`) values (2,'2','2','2','2'),(4,'1','2','3','4'),(5,'1','2','3','4'),(6,'1','2','3','4'),(7,'1','2','3','4'),(8,'1','2','3','4'),(9,'1','2','3','4'),(10,'1','2','3','4'),(11,'1','2','3','4'),(12,'1','2','3','4'),(13,'1','2','3','4'),(14,'1','2','3','4'),(15,'1','2','3','4'),(16,'1','2','3','4'),(17,'1','2','3','4'),(18,'1','2','3','4'),(19,'1','2','3','4'),(20,'1','2','3','4'),(21,'1','2','3','4'),(22,'1','2','3','4'),(23,'1','2','3','4'),(24,'1','2','3','4'),(25,'1','2','3','4'),(26,'1','2','3','4'),(27,'1','2','3','4'),(28,'1','2','3','4'),(29,'1','2','3','4'),(30,'1','2','3','4'),(31,'1','2','3','4'),(32,'1','2','3','4'),(33,'1','2','3','4'),(34,'1','2','3','4'),(35,'1','2','3','4'),(36,'1','2','3','4'),(37,'1','2','3','4'),(38,'1','2','3','4'),(39,'1','2','3','4'),(40,'1','2','3','4'),(41,'1','2','3','4'),(42,'1','2','3','4'),(43,'1','2','3','4'),(44,'1','2','3','4'),(45,'1','2','3','4'),(46,'1','2','3','4'),(47,'1','2','3','4'),(48,'1','2','3','4'),(49,'1','2','3','4'),(50,'1','2','3','4'),(51,'1','2','3','4'),(52,'1','2','3','4'),(53,'1','2','3','4'),(54,'1','2','3','4'),(55,'1','2','3','4'),(56,'1','2','3','4'),(57,'1','2','3','4'),(58,'1','2','3','4'),(59,'1','2','3','4'),(60,'1','2','3','4'),(61,'1','2','3','4'),(62,'1','2','3','4'),(63,'1','2','3','4'),(64,'1','2','3','4'),(65,'1','2','3','4'),(66,'1','2','3','4'),(67,'1','2','3','4'),(68,'1','2','3','4'),(69,'1','2','3','4'),(70,'1','2','3','4'),(71,'1','2','3','4'),(72,'1','2','3','4'),(73,'1','2','3','4'),(74,'1','2','3','4'),(75,'1','2','3','4'),(76,'1','2','3','4'),(77,'1','2','3','4'),(78,'1','2','3','4'),(79,'1','2','3','4'),(80,'1','2','3','4'),(81,'1','2','3','4'),(82,'1','2','3','4'),(83,'1','2','3','4'),(84,'1','2','3','4'),(85,'1','2','3','4'),(86,'1','2','3','4'),(87,'1','2','3','4'),(88,'1','2','3','4'),(89,'1','2','3','4'),(90,'1','2','3','4'),(91,'1','2','3','4'),(92,'1','2','3','4'),(93,'1','2','3','4'),(94,'1','2','3','4'),(95,'1','2','3','4'),(96,'1','2','3','4'),(97,'1','2','3','4'),(98,'1','2','3','4'),(99,'1','2','3','4'),(100,'1','2','3','4'),(101,'1','2','3','4'),(102,'1','2','3','4'),(103,'1','2','3','4'),(104,'1','2','3','4'),(105,'1','2','3','4'),(106,'1','2','3','4'),(107,'1','2','3','4'),(108,'1','2','3','4'),(109,'1','2','3','4'),(110,'1','2','3','4'),(111,'1','2','3','4'),(112,'1','2','3','4'),(113,'1','2','3','4'),(114,'1','2','3','4'),(115,'1','2','3','4'),(116,'1','2','3','4'),(117,'1','2','3','4'),(118,'1','2','3','4'),(119,'1','2','3','4'),(120,'1','2','3','4'),(121,'1','2','3','4'),(122,'1','2','3','4'),(123,'4','2','3','4'),(124,'3','2','3','4');

/*Table structure for table `t_memo` */

DROP TABLE IF EXISTS `t_memo`;

CREATE TABLE `t_memo` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `headLine` varchar(255) DEFAULT NULL COMMENT '备忘录标题',
  `content` longtext COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COMMENT='备忘录';

/*Data for the table `t_memo` */

insert  into `t_memo`(`id`,`headLine`,`content`) values (1,'开心的一天','\r\n$(function () {\r\n        let db = \'\';\r\n\r\n        (function () {  // 定义一个匿名自执行函数\r\n            getInfo(function () {  // 执行 getInfo 函数，并将一个匿名函数当做参数传递过去\r\n                console.log(db);\r\n            })\r\n        })()\r\n\r\n        function getInfo(callback) {\r\n            $.ajax({\r\n                url: \'http://api.douban.com/v2/movie/top250\',\r\n                async: true,\r\n                dataType: \'jsonp\',\r\n                success(result) {\r\n                    db = result;\r\n                    callback(db);  // 执行传递过来的匿名函数\r\n                },\r\n                error(err) {\r\n                    console.log(err);\r\n                }\r\n            })\r\n        }\r\n    })'),(3,'123','123xxx\nxxx\n\nxxxx'),(4,'心情','今天非常难过\n'),(5,'123','asda \n\nqwe\n\nxxx'),(6,'123','asd开心'),(7,'`12','`12'),(8,'1231','12321321'),(9,'99999','999999');

/*Table structure for table `t_rights` */

DROP TABLE IF EXISTS `t_rights`;

CREATE TABLE `t_rights` (
  `rightsId` int(11) NOT NULL AUTO_INCREMENT COMMENT '权限id',
  `rightsName` varchar(255) NOT NULL COMMENT '权限名称',
  `rightsPath` varchar(255) NOT NULL COMMENT '权限地址',
  PRIMARY KEY (`rightsId`)
) ENGINE=InnoDB AUTO_INCREMENT=80 DEFAULT CHARSET=utf8 COMMENT='权限表';

/*Data for the table `t_rights` */

insert  into `t_rights`(`rightsId`,`rightsName`,`rightsPath`) values (1,'用户管理','/a_usermanager/UserManager.jsp'),(2,'角色管理','/a_rolemanager/RoleManager.jsp'),(3,'权限管理','/a_rightsmanager/RightsManager.jsp'),(4,'学生管理','/a_studentmanager/StudentManager.jsp'),(5,'班级管理','/a_classmanager/ClassManager.jsp'),(6,'宿舍管理','/a_dormmanager/DormManager.jsp'),(7,'备忘录管理','/a_memomanager/MemoManager.jsp'),(8,'违纪管理','/a_foulmanager/FoulManager.jsp'),(9,'日志管理','/a_logmanager/LogManager.jsp');

/*Table structure for table `t_role` */

DROP TABLE IF EXISTS `t_role`;

CREATE TABLE `t_role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT COMMENT '角色id',
  `roleName` varchar(255) NOT NULL COMMENT '角色名称',
  PRIMARY KEY (`roleId`),
  UNIQUE KEY `roleName` (`roleName`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='角色表';

/*Data for the table `t_role` */

insert  into `t_role`(`roleId`,`roleName`) values (1,'超级账户');

/*Table structure for table `t_role_rights` */

DROP TABLE IF EXISTS `t_role_rights`;

CREATE TABLE `t_role_rights` (
  `roleId` int(11) NOT NULL COMMENT '角色id',
  `rightsId` int(11) NOT NULL COMMENT '权限id',
  UNIQUE KEY `roleId` (`roleId`,`rightsId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='角色表&权限表';

/*Data for the table `t_role_rights` */

insert  into `t_role_rights`(`roleId`,`rightsId`) values (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9);

/*Table structure for table `t_stu_class` */

DROP TABLE IF EXISTS `t_stu_class`;

CREATE TABLE `t_stu_class` (
  `stuId` int(11) DEFAULT NULL COMMENT '学生ID',
  `classId` int(11) DEFAULT NULL COMMENT '班级id',
  UNIQUE KEY `stuId` (`stuId`,`classId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生表&班级表';

/*Data for the table `t_stu_class` */

insert  into `t_stu_class`(`stuId`,`classId`) values (269,1),(269,4),(274,1),(276,1),(280,5),(289,4),(290,1),(291,4),(294,1),(295,5),(296,5),(297,5),(298,5),(299,5),(300,5),(301,5),(302,5),(303,5),(304,5),(305,5),(306,5),(307,5),(308,5),(309,5),(310,5),(311,5),(312,5),(313,5),(314,5),(315,5),(318,4),(333,4),(371,6),(372,6),(373,6),(384,5),(393,5),(394,6),(395,5);

/*Table structure for table `t_stu_dorm` */

DROP TABLE IF EXISTS `t_stu_dorm`;

CREATE TABLE `t_stu_dorm` (
  `stuId` int(11) DEFAULT NULL COMMENT '学生ID',
  `dormId` int(11) DEFAULT NULL COMMENT '宿舍id',
  UNIQUE KEY `stuId` (`stuId`,`dormId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生表&宿舍表';

/*Data for the table `t_stu_dorm` */

insert  into `t_stu_dorm`(`stuId`,`dormId`) values (332,3);

/*Table structure for table `t_stu_stuunion` */

DROP TABLE IF EXISTS `t_stu_stuunion`;

CREATE TABLE `t_stu_stuunion` (
  `stuId` int(11) DEFAULT NULL COMMENT '学生Id',
  `stuUnionId` int(11) DEFAULT NULL COMMENT '学生会id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生表& 学生会表';

/*Data for the table `t_stu_stuunion` */

/*Table structure for table `t_student` */

DROP TABLE IF EXISTS `t_student`;

CREATE TABLE `t_student` (
  `stuId` int(11) NOT NULL AUTO_INCREMENT COMMENT '学生id，自动增长，不需要用户输入',
  `stuName` varchar(255) NOT NULL COMMENT '学生姓名',
  `stuAge` varchar(255) NOT NULL COMMENT '学生年龄',
  `stuSex` varchar(255) NOT NULL COMMENT '学生性别',
  `idCard` varchar(255) DEFAULT NULL COMMENT '身份证号码',
  `qqEmail` varchar(255) DEFAULT NULL COMMENT 'qq邮箱',
  `wechat` varchar(255) DEFAULT NULL COMMENT '微信号码',
  `myPhone` varchar(255) DEFAULT NULL COMMENT '本人电话号码',
  `superPhone` varchar(255) DEFAULT NULL COMMENT '父/母电话号码',
  PRIMARY KEY (`stuId`)
) ENGINE=InnoDB AUTO_INCREMENT=397 DEFAULT CHARSET=utf8 COMMENT='学生表';

/*Data for the table `t_student` */

insert  into `t_student`(`stuId`,`stuName`,`stuAge`,`stuSex`,`idCard`,`qqEmail`,`wechat`,`myPhone`,`superPhone`) values (269,'张三','11','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(274,'123','123','男','123','123','12','3123','123'),(276,'王麻子','2','女','431103201909028883','12322@qq.com','l246810333','1008611','1001011'),(280,'张三','6','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(289,'张三','1','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(290,'王麻子','2','女','431103201909028883','12322@qq.com','l246810333','1008611','1001011'),(291,'张三','3','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(294,'张三','6','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(295,'张三','7','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(296,'张三','8','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(297,'张三','9','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(298,'张三','10','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(299,'张三','11','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(300,'张三','12','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(301,'张三','13','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(302,'张三','14','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(303,'张三','1','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(304,'王麻子','2','女','431103201909028883','12322@qq.com','l246810333','1008611','1001011'),(305,'张三','3','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(306,'张三','4','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(307,'张三','5','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(308,'张三','6','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(309,'张三','7','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(310,'张三','8','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(311,'张三','9','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(312,'张三','10','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(313,'张三','11','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(314,'张三','12','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(315,'张三','13','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(317,'张三','1','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(318,'王麻子','2','女','431103201909028883','12322@qq.com','l246810333','1008611','1001011'),(332,'xxx','4','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(333,'洋洋','5','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(337,'张三','14','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(338,'水牛','12','男','222','222','222','222','222'),(339,'123','123','男','123','123','12','3123','123'),(341,'王麻子','2','女','431103201909028883','12322@qq.com','l246810333','1008611','1001011'),(371,'张三','4','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(372,'张三','5','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(373,'张三','6','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(374,'张三','7','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(375,'张三','8','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(376,'张三','9','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(377,'张三','10','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(378,'张三','11','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(379,'张三','12','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(380,'张三','13','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(381,'张三','14','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(382,'张三','1','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(383,'王麻子','2','女','431103201909028883','12322@qq.com','l246810333','1008611','1001011'),(384,'张三','3','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(385,'张三','4','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(386,'张三','5','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(387,'张三','6','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(388,'张三','7','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(389,'张三','8','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(390,'张三','9','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(391,'张三','10','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(392,'张三','11','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(393,'张三','12','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(394,'张三','13','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(395,'张三','14','男','431103201909028883','123@qq.com','l246810','1008611','1001011'),(396,'222','222','男','222','222','222','222','222');

/*Table structure for table `t_stuunion` */

DROP TABLE IF EXISTS `t_stuunion`;

CREATE TABLE `t_stuunion` (
  `stuUnionId` int(11) NOT NULL AUTO_INCREMENT COMMENT '学生会id 表示部门与角色',
  `section` varchar(255) DEFAULT NULL COMMENT '学生会部门 纪律部_文体宣_学习部',
  `stuRole` varchar(255) DEFAULT NULL COMMENT '学生会角色',
  PRIMARY KEY (`stuUnionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学生会表';

/*Data for the table `t_stuunion` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
